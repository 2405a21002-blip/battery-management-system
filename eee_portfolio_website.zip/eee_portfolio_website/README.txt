EEE Personal Portfolio Website

1. Open index.html in a browser to preview the website.
2. Replace every instance of "Your Name" and the sample email/LinkedIn details.
3. Review project descriptions and add only accurate details, dates, photos and results.
4. To publish it free with GitHub Pages:
   - Create/sign in to a GitHub account.
   - Create a new public repository named eee-portfolio (or any name).
   - Upload index.html to the repository root.
   - Open Settings > Pages.
   - Under Build and deployment, choose Deploy from a branch.
   - Select main and /(root), then Save.
   - GitHub will provide a public website URL after deployment.
This is a starter website; it has not been published online yet.
